import { Container, Stack } from "@mui/material";

import { BroswerRouter as Router, Route, Switch } from "react-router-dom"

import AppBar from "./components/AppBar/AppBar";

import DatabaseTable from "./components/DatabaseTable/DatabaseTable";
import SideBar from "./components/SideBar/SideBar";
import Login from "./pages/Login"
import AddAdmin from "./pages/AddAdmin"

function App() {
  return (
    <Router >
      <Container sx={{ backgroundColor: "#443955", borderRadius: "10px" }}>
        <AppBar />
        <br />
        <Switch>
          <Route exact path="/">
            <Login />
          </Route>
          <Route exact path="/admin">
            <Stack direction={{ xs: 'column', sm: 'row' }}
              spacing={{ xs: 1, sm: 2, md: 4 }}>
              <SideBar />
              <DatabaseTable />
            </Stack>
          </Route>
          <Route exact path="/admin/addadmin">
            <AddAdmin />
          </Route>
        </Switch>

      </Container>
    </Router>
  );
}

export default App;
