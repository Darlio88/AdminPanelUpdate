import { Typography, Grid, Avatar, Paper, TextField, Button } from '@mui/material'
import React from 'react'
import { LockOutlinedIcon } from '@mui/icons-material'
export default function Login() {
    return (
        <Grid >
            <Paper elevation={5} sx={{ padding: 20, height: "70vh", width: 280, margin: "20px auto" }}>
                <Grid align="center">
                    <Avatar sx={{ backgroundColor: "green", }}><LockOutlinedIcon /></Avatar>
                    <Typography variant="h4" component="h1">Login as Admin</Typography>
                </Grid>
                <form onSubmit={ } method="post"> <TextField label="UserName" required fullWidth placeholder="Enter your username...." />
                    <TextField label="Password" required type="password" fullWidth placeholder="Enter your password...." />
                    <Button type="submit" color="primary" fullWidth variant="contained">Sign in</Button>
                    </form>

            </Paper>
        </Grid>
    )
}
