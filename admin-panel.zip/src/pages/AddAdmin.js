import { TextField, Button } from '@mui/material'
import React from 'react'

export default function AddAdmin() {
    return (
        <Grid >
            <Paper elevation={5} sx={{ padding: 20, height: "70vh", width: 280, margin: "20px auto" }}>
                <Grid align="center">
                    <Avatar sx={{ backgroundColor: "green", }}><LockOutlinedIcon /></Avatar>
                    <Typography variant="h4" component="h1">Login as Admin</Typography>
                </Grid>
                <form onSubmit={ } method='POST'>
                    <TextField label="User Name" placeholder="Enter User name...." required fullWidth />
                    <TextField label="Email" placeholder="Enter Email..." required fullWidth type="email" />
                    <Button type="submit" >Add</Button>
                </form>
            </Paper>
        </Grid>
    )
}
